package com.example.demo.dto;

import jakarta.validation.constraints.*;
import lombok.*;

@Data\n@NoArgsConstructor
public class PedidoRequest {
}
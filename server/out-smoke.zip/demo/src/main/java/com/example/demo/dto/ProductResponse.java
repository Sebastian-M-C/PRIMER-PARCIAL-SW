package com.example.demo.dto;

import lombok.*;

@Data\n@NoArgsConstructor\n@AllArgsConstructor\n@Builder
public class ProductResponse {

    private Long id;

    private String name;
}
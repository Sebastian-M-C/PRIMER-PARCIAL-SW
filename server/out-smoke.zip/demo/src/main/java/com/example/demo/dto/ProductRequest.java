package com.example.demo.dto;

import jakarta.validation.constraints.*;
import lombok.*;

@Data\n@NoArgsConstructor\n@AllArgsConstructor\n@Builder
public class ProductRequest {

    @NotNull
    @NotBlank
    private String name;
}
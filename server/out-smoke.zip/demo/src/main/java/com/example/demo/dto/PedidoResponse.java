package com.example.demo.dto;

import lombok.*;

@Data\n@NoArgsConstructor\n@AllArgsConstructor\n@Builder
public class PedidoResponse {

    private Long id;
}